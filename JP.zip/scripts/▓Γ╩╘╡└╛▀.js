function onUse(event) {
  let player = event.getPlayer();
  let world = player.getWorld();
  let eyeLocation = player.getEyeLocation();
  let direction = eyeLocation.getDirection();
  let notplayer = eyeLocation.add(0, -0.7, 0).add(direction);
  let maxDistance = 100;
  let rayTraceResults = world.rayTrace(notplayer, direction, maxDistance, org.bukkit.FluidCollisionMode.ALWAYS, true, 0, null);

  if (rayTraceResults === null) {
    return;
  }

  let entity = rayTraceResults.getHitEntity();
  if (entity !== null) {
    player.sendMessage(rayTraceResults);
  }
}
