function onUse(event) {
  var player = event.getPlayer();
  var offHandItem = player.getInventory().getItemInOffHand();
  if (offHandItem === null) {
    player.sendMessage("您的副手没有持有物品。");
    return;
  }

  var enchantments = offHandItem.getEnchantments(); // 获取附魔Map
  var maxEnchantmentLevel = 0;
  enchantments.forEach(function(entry) { // 遍历Map
    var enchantment = entry.getKey();
    var level = entry.getValue();
    if (level > maxEnchantmentLevel) {
      maxEnchantmentLevel = level;
    }
  });

  if (maxEnchantmentLevel > 0) {
    var upgradeChance = calculateUpgradeChance(maxEnchantmentLevel);
    var randomChance = Math.random();
    player.sendMessage("随机概率: " + (randomChance * 100) + "%");

    if (randomChance < upgradeChance) {
      upgradeEnchantments(offHandItem);
      player.sendMessage("附魔等级提升。");
    } else {
      player.getInventory().setOffHand(null);
      player.sendMessage("附魔失败，装备已销毁。");
    }
  } else {
    player.sendMessage("副手装备没有附魔。");
  }
}

function calculateUpgradeChance(level) {
  var baseChance = 1.0;
  var decreasePerTenLevels = 0.02;
  while (level >= 10) {
    baseChance -= decreasePerTenLevels;
    level -= 10;
  }
  return baseChance;
}

function upgradeEnchantments(item) {
  var enchantments = item.getEnchantments();
  enchantments.forEach(function(entry) { // 遍历Map
    var enchantment = entry.getKey();
    var level = entry.getValue();
    if (level < 255) {
      var newLevel = level + 1;
      item.removeEnchantment(enchantment); // 移除附魔
      // 请注意，addUnsafeEnchantment 在 Bukkit API 中不存在
      // 您需要使用 addEnchantment 并确保您有正确的权限和 API 支持
      item.addEnchantment(enchantment, newLevel);
    }
  });
}